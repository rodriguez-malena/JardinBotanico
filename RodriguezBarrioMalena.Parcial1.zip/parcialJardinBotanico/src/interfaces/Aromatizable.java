
package interfaces;


public interface Aromatizable {
    void desprenderAroma();
}
