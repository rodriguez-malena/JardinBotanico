
package model;

import interfaces.Aromatizable;
import interfaces.Podable;


public class Arbol extends Planta implements Podable, Aromatizable{
    private final int MIN_ALTURA = 1;
    private final int MAX_ALTURA = 30;
    
    
    private double altura;
    
    
    public Arbol(String nombre, String ubicacion, String clima, double altura) {
        super(nombre, ubicacion, clima);
        validarAltura(altura);
        this.altura = altura;
    }
    
    private void validarAltura(double altura){
        if(altura < MIN_ALTURA || altura > MAX_ALTURA){
            throw new IllegalArgumentException("La altura " + altura + " metros no coincide con los limites");
        }
    }
    
    @Override
    public void podar() {
        System.out.println("Soy el arbol  "  + super.getNombre() + " y me estan podando");
    }

    @Override
    public void desprenderAroma() {
        System.out.println("Soy el arbol " + super.getNombre() + " y desprendo mi olor" );
    }

    @Override
    public String toString() {
        return "Arbol{" + "Nombre: " + super.getNombre() +
                ", ubicacion: " + super.getUbicacion() +
                ", clima: " + super.getClima() + 
                ", altura:  " + altura + '}';
    }
    
    
    
    
}
