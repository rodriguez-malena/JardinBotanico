
package model;

import interfaces.Podable;


public class Arbusto extends Planta implements Podable {
    private final int MIN_DENSIDAD = 1;
    private final int MAX_DENSIDAD = 10;
    
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        validarDensidadFollaje(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }
    
    private void validarDensidadFollaje(int densidadFollaje){
        if(densidadFollaje < MIN_DENSIDAD || densidadFollaje > MAX_DENSIDAD){
            throw new IllegalArgumentException("La densidad " + densidadFollaje + " no coincide con los limites");
        }
    }

    @Override
    public void podar() {
        System.out.println("Soy el arrbusto " + super.getNombre() + " y me estan podando");
    }

    @Override
    public String toString() {
        return "Arbusto{" + "Nombre: " + super.getNombre() +
                ", ubicacion: " + super.getUbicacion() +
                ", clima: " + super.getClima() +
                ", densidad de follaje:  " + densidadFollaje + '}';
    }
    
    
    
}
