
package model;

import interfaces.Aromatizable;


public class Flor extends Planta implements Aromatizable{
    private Temporada temporada;

    public Flor(String nombre, String ubicacion, String clima, Temporada temporada) {
        super(nombre, ubicacion, clima);
        validarTemporada(temporada);
        this.temporada = temporada;
    }
    
    
    private void validarTemporada(Temporada temporada){
        if(temporada == null){
            throw new IllegalArgumentException("Ingrese un tipo temporada valido");
        }     
    }
    
    public boolean esTemporada(Temporada temporada){
        return this.temporada == temporada;
    }
    
   
    
    @Override
    public void desprenderAroma() {
        System.out.println("Soy la rosa " + super.getNombre() + " y desprendo mi aroma");
    }

    @Override
    public String toString() {
        return "Flor{" + "Nombre: " + super.getNombre() +
                ", ubicacion: " + super.getUbicacion() +
                ", clima: " + super.getClima() +
                ", temporada: " + temporada + '}';
    }
    
    
    
    
}
