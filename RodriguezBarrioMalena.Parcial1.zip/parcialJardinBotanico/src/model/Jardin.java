
package model;

import exceptions.PlantaRepetidaException;
import interfaces.Aromatizable;
import interfaces.Podable;
import java.util.ArrayList;
import java.util.List;


public class Jardin {
    
    private List<Planta>plantas;

    public Jardin() {
        this.plantas = new ArrayList<>();
    }
    
    
    private void checkNullPlanta(Planta planta){
        if (planta == null){
            throw new NullPointerException("La planta no puede ser nula");
        }
    }
    
    private void validarPlantaRepetida(Planta planta){
        if(plantas.contains(planta)){
            throw new PlantaRepetidaException("La planta " + planta.getNombre()  + " ya fue ingresada" );
        }
    }
    
    public void agregarPlanta(Planta planta){
        checkNullPlanta(planta);
        validarPlantaRepetida(planta);
        plantas.add(planta);
   
    }
    
    private boolean validarListaPlantas(){
        return !(plantas.isEmpty());
   
    }
    
    public void mostrarPlantas(){
        if(validarListaPlantas()){
            for(Planta planta : plantas){
                System.out.println(planta);
            }
        }   
    }
    
    public void podarPlantas(){
        for(Planta planta : plantas){
            if(planta instanceof Podable p){
                p.podar();           
            } else {
                System.out.println("La planta " + planta.getNombre() + " no puede podarse");
            }
        }
        
    }
    
    public void hacerDesprenderAroma(){
        for(Planta planta: plantas){
            if(planta instanceof Aromatizable a){
                a.desprenderAroma();
            } else{
                System.out.println("La planta " + planta.getNombre() + " no puede aromatizar");
            }
        }
    }
    
    public List <Planta> filtrarPorTemporadaFlorecimiento(Temporada temporada){
        List <Planta> floresPorTemporada = new ArrayList<>();
        
        for (Planta planta : plantas){
            if (planta instanceof Flor flor && flor.esTemporada(temporada)){
                floresPorTemporada.add(flor);
            }   
        }
         return floresPorTemporada;
    }
    
    public void mostrarPorTemporadaFlorecimiento(Temporada temporada){
        List<Planta> floresFiltradas = filtrarPorTemporadaFlorecimiento(temporada);
        if(floresFiltradas.isEmpty()){
            System.out.println("No hay flores en la temporada: " + temporada);
            
        }else{
            System.out.println("Flores de la temporada " + temporada + ":");
            for(Planta p  : floresFiltradas){
                System.out.println(p);
            }
        }
    }
    
    
}
