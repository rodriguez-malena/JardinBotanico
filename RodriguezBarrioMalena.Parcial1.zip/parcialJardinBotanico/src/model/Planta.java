
package model;

import java.util.Objects;


public abstract class Planta {
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        validaciones(nombre,ubicacion,clima);
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    
    private void validarNombrePlanta(String nombre){
        if(nombre == null || nombre.isEmpty()){
            throw new IllegalArgumentException("Ingrese un nombre de  planta valido");
        }
    }
    
    private void validarUbicacion(String ubicacion){
        if(ubicacion == null || ubicacion.isEmpty()){
            throw new IllegalArgumentException("Ingrese una ubicacion valida");
        }
    }
    
    private void vaidarClima(String clima){
        if(clima == null || clima.isEmpty()){
            throw new IllegalArgumentException("Ingrese un clima valido");   
        }
    }
    
    private void validaciones(String nombre, String ubicacion, String clima){
        validarNombrePlanta(nombre);
        validarUbicacion(ubicacion);
        vaidarClima(clima);
    }
           
    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getClima() {
        return clima;
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Planta p)){
            return false;
        }
        return this.nombre.equals(p.nombre)&& this.ubicacion.equals(p.ubicacion);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre,ubicacion);
    }
}
