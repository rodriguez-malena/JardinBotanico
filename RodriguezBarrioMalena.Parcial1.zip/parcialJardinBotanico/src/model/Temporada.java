
package model;


public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO,
}
