
package parcialjardinbotanico;

import model.Arbol;
import model.Arbusto;
import model.Flor;
import model.Jardin;
import model.Temporada;

public class ParcialJardinBotanico {

   
    public static void main(String[] args) {
        try{
            Jardin jardinBotanico  = new Jardin();
            
            jardinBotanico.agregarPlanta(new Arbol("Roble","Norte","Templado", 25.5));
            jardinBotanico.agregarPlanta(new Arbol("Roble","Norte","Templado",3.5));

            jardinBotanico.agregarPlanta(new Arbusto("Romero","Este","Calido", 4));
            jardinBotanico.agregarPlanta(new Arbusto("Lavanda","Este","Calido", 3));

            jardinBotanico.agregarPlanta(new Flor("Rosa","Sur","Templado",Temporada.PRIMAVERA));
            jardinBotanico.agregarPlanta(new Flor("Jazmin","Norte","Templado",Temporada.PRIMAVERA));
            jardinBotanico.agregarPlanta(new Flor("Margarita","Oeste","Templado",Temporada.OTONIO));
        
            jardinBotanico.mostrarPlantas();
        
            jardinBotanico.podarPlantas();
            
            jardinBotanico.hacerDesprenderAroma();
            
            jardinBotanico.mostrarPorTemporadaFlorecimiento(Temporada.PRIMAVERA);
            
    
            
        }catch (RuntimeException ex){
            System.out.println(ex.getMessage());
        }
        
        
        
        
        

    }
    
}
